<?php
	include 'header.php';
	include 'navbar.php';
?>
				
					<div class="content mt-3">
						<div class="row">
							<div class="col-sm-3">								
								<div class="card">
									<div class="card-body bg-success bg-gradient text-center">
									<h3>Data Buku</h3>
									<?php
									include '../koneksi.php';
									$data_buku = mysqli_query($koneksi,"SELECT * FROM buku");
									$jumlah_buku = mysqli_num_rows($data_buku);
									?>
									<h3><?php echo $jumlah_buku; ?></h3>
										<a href="#" class="btn btn-dark btn-sm">Lihat Data</a>
									</div>
								</div>
							</div>
							<div class="col-sm-3">								
								<div class="card">
									<div class="card-body bg-danger text-center">
										<h3>Kategori Buku</h3>
										<?php
										include '../koneksi.php';
										$data_kategori = mysqli_query($koneksi,"SELECT * FROM kategoribuku");
										$jumlah_kategori = mysqli_num_rows($data_kategori);
										?>
										<h3><?php echo $jumlah_kategori; ?></h3>
										<a href="#" class="btn btn-dark btn-sm">Lihat Data</a>
									</div>
								</div>
							</div>
							<div class="col-sm-3">								
								<div class="card">
									<div class="card-body bg-info text-center">
										<h3>Users</h3>
										<?php
										include '../koneksi.php';
										$data_users = mysqli_query($koneksi,"SELECT * FROM user");
										$jumlah_users = mysqli_num_rows($data_users);
										?>
										<h3><?php echo $jumlah_users; ?></h3>
										<a href="#" class="btn btn-dark btn-sm">Lihat Data</a>
									</div>
								</div>
							</div>
							<div class="col-sm-3">								
								<div class="card">
									<div class="card-body bg-primary text-center">
										<h3>Peminjaman</h3>
										<?php
										include '../koneksi.php';
										$data_peminjaman = mysqli_query($koneksi,"SELECT * FROM peminjaman");
										$jumlah_peminjaman = mysqli_num_rows($data_peminjaman);
										?>
										<h3><?php echo $jumlah_peminjaman; ?></h3>
										<a href="Laporan_Peminjaman.php" class="btn btn-dark btn-sm">Lihat Data</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="content mt-3">
							<div class="card">
								<div class="card-body">
								<p>Halo <b><?php echo $_SESSION['Username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['Level']; ?></b>.
								</p>
								</div>
							</div>
						</div>


<?php
	include 'footer.php';
?>

 